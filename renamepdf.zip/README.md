# RenamePDF

Web app untuk rename file PDF secara online.

## Cara Deploy

1. Push ke GitHub repo bernama `renamepdf`.
2. Hubungkan ke [Vercel](https://vercel.com).
3. Deploy otomatis.
